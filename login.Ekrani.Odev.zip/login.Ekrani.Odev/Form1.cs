namespace login.Ekrani.Odev
{
    public partial class Form1 : Form
    {
        private string username;
        private string password;    
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            username = usernameTxt.Text;
            password = passwordTxt.Text;

            if (username == "" || password == "")
            {
                MessageBox.Show("L�tfen t�m alanlar� doldurun.");
            }
            else if (username == "asd123" && password == "asd123")
            {
                Form2 yeniSayfa = new Form2();
                this.Hide();
                MessageBox.Show("Giri� Ba�ar�l�");
                yeniSayfa.ShowDialog();
                this.Show();
                
            }
            else
                MessageBox.Show("Bilgilerinizi kontrol ediniz.");
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox1.CheckState==CheckState.Checked)
            {
                passwordTxt.UseSystemPasswordChar = true;

            }
            else { passwordTxt.UseSystemPasswordChar = false; }
        }
    }
}